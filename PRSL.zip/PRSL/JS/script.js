Chart.helpers.merge(Chart.defaults.global.plugins.datalabels, {
    backgroundColor: function (context) {
        return context.dataset.backgroundColor;
    },
    borderRadius: 4,
    color: "white",
    font: {
        weight: "bolder",
        size: 13,
    },
    formatter: Math.round,
    padding: 2,
});
$(document).ready(function() { 
    //On Load Animation
    AOS.init({
        duration: 1200,
    });
    //Slider Part
    var instance = M.Carousel.init({
        fullWidth: true,
    });
    $(".carousel.carousel-slider").carousel({
        fullWidth: true,
    });
    // move next carousel
    $(".moveNextCarousel").click(function (e) {
        e.preventDefault();
        e.stopPropagation();
        $(".carousel").carousel("next");
    });
    // move prev carousel
    $(".movePrevCarousel").click(function (e) {
        e.preventDefault();
        e.stopPropagation();
        $(".carousel").carousel("prev");
    }); 
    //DropDowns
    $.ajax({
        url: '/XMII/Illuminator?QueryTemplate=MANUFACTURING_WORKBENCH%2FDASHBOARD%2FCOMMON%2FTRANSACTION%2FXCT_QRY_GET_PROFILE_DATA&IsTesting=T&Content-Type=text%2Fjson',
        type: 'GET',
        data: {},
        dataType: 'json',
        success: function(response) {
            $("#plant").empty();
            $("#plant").append("<option value='' disabled>Select Plant</option>");
            var len = response.length;
            for (var j = 0; j < Object.keys(response.Rowsets.Rowset[0].Row).length; j++) {
                var plant = response.Rowsets.Rowset[0].Row[j].PLANT;
                var plantcode = response.Rowsets.Rowset[0].Row[j].PLANT_CODE;
                $("#plant").append("<option value='" + plant + "'>" + plant +'-'+ plantcode + "</option>");
            }
        }
    });
    $.ajax({
        url: '/XMII/Illuminator?QueryTemplate=MANUFACTURING_WORKBENCH%2FDASHBOARD%2FCOMMON%2FTRANSACTION%2FXACUTE_GET_STREAM&IsTesting=T&Content-Type=text%2Fjson',
        type: 'GET',
        data: {},
        dataType: 'json',
        success: function(response) {
            $("#stream").empty();
            $("#stream").append("<option value='' disabled>Select Stream</option>");
            var len = response.length;
            for (var j = 0; j < Object.keys(response.Rowsets.Rowset[0].Row).length; j++) {
                var stream = response.Rowsets.Rowset[0].Row[j].STREAM;
                $("#stream").append("<option value='" + stream + "'>" + stream + "</option>");
            }
        }
    });
    $.ajax({
        url: '/XMII/Illuminator?QueryTemplate=MANUFACTURING_WORKBENCH%2FDASHBOARD%2FCOMMON%2FTRANSACTION%2FXACUTE_GET_SECTION&IsTesting=T&Content-Type=text%2Fjson',
        type: 'GET',
        data: {},
        dataType: 'json',
        success: function(response) {
            $("#section").empty();
            $("#section").append("<option value='' disabled>Select Section</option>");
            var len = response.length;
            for (var j = 0; j < Object.keys(response.Rowsets.Rowset[0].Row).length; j++) {
                var section = response.Rowsets.Rowset[0].Row[j].SECTION;
                $("#section").append("<option value='" + section + "'>" + section + "</option>");
            }
        }
    });
    $.ajax({
        url: '/XMII/Illuminator?QueryTemplate=MANUFACTURING_WORKBENCH%2FDASHBOARD%2FCOMMON%2FTRANSACTION%2FXACUTE_GET_PACK_SIZE&IsTesting=T&Content-Type=text%2Fjson',
        type: 'GET',
        data: {},
        dataType: 'json',
        success: function(response) {
            $("#packsize").empty();
            $("#packsize").append("<option value='' disabled>Select Packsize</option>");
            var len = response.length;
            for (var j = 0; j < Object.keys(response.Rowsets.Rowset[0].Row).length; j++) {
                var packsize = response.Rowsets.Rowset[0].Row[j].PACK_SIZE;
                $("#packsize").append("<option value='" + packsize + "'>" + packsize + "</option>");
            }
        }
    });
    $.ajax({
        url: '/XMII/Illuminator?QueryTemplate=MANUFACTURING_WORKBENCH%2FDASHBOARD%2FQUERY%2FSQL_GET_WORKING_DAYS&IsTesting=T&Content-Type=text%2Fjson',
        type: 'GET',
        data: {},
        dataType: 'json',
        success: function(response) {
            $('#actualworkingdays').val(response.Rowsets.Rowset[0].Row[0].ACTUAL_WORKING_DAYS);
            $('#workeddays').val(response.Rowsets.Rowset[0].Row[0].WORKED_DAYS);
            $('#balancedays').val(response.Rowsets.Rowset[0].Row[0].BALANCED_DAYS);
        }
    });
});


const q = document.querySelector.bind(document);
const ctx = q("#PRSLSKUCOMPLETION");
const chart = new Chart(ctx, {
    type: "pie",
    data: {
        labels: ["SKU Completed","SKU Pending"],
        datasets: [
            {
                data: [40,100],
                backgroundColor: ["rgba(46, 204, 113, 1)","rgba(255, 164, 46, 1)"],
                borderColor: ["rgba(46, 204, 113, 1)","rgba(255, 164, 46, 1)"],
                borderWidth: 1,
            },
        ],
    },
    options: {
        title: {
            display: true,
            text: "PRSL SKU Completion",
            fontSize: "16",
        },
    },
});
window.randomScalingFactor = function () {
    return Math.random() * 50;
};

var proratedprsldata = {
    labels: ["Total"],
    datasets: [
        {
            label: "No of SKU",
            backgroundColor: "rgba(255, 164, 46, 1)",
            data: [randomScalingFactor()],
        },
        {
            label: "SKU Completed",
            backgroundColor: "#3498db",
            data: [randomScalingFactor()],
        },
    ],
};
var prsltrenddata = {
    labels: ["01-Apr-2021", "02-Apr-2021", "03-Apr-2021", "04-Apr-2021", "05-Apr-2021"],
    datasets: [
        {
            fill: false,
            label: "Frequency",
            backgroundColor: "#3498db",
            borderColor:"#3498db",
            data: [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor()],
        },
    ],
};


window.onload = function () {
    
    var ctx = document.getElementById("PRORATEDPRSL").getContext("2d");
    window.myBar = new Chart(ctx, {
        type: "bar",
        data: proratedprsldata,
        options: {
            legend: {
                display: true,
            },
            title: {
                display: true,
                text: "Pro-Rated PRSL",
                fontSize: "16",
            },
            tooltips: {
                mode: "index",
                intersect: false,
            },
            scales: {
                yAxes: [
                    {
                        ticks: {
                            stepSize: 20,
                        },
                    },
                ],
            },
            responsive: true,
        },
    });
    var ctx = document.getElementById("PRSLTREND").getContext("2d");
    window.myBar = new Chart(ctx, {
        type: "line",
        data: prsltrenddata,
        options: {
            legend: {
                display: true,
            },
            title: {
                display: true,
                text: "PRSL Trend(FY)",
                fontSize: "16",
            },
            tooltips: {
                mode: "index",
                intersect: false,
            },
            scales: {
                xAxes: [
                    {
                        stacked: true,
                    },
                ],
                yAxes: [
                    {
                        ticks: {
                            stepSize: 20,
                        },
                        stacked: true,
                    },
                ],
            },
            responsive: true,
        },
    });
    var $el = $(".table-responsive");

    function anim() {
        var st = $el.scrollTop();
        var sb = $el.prop("scrollHeight") - $el.innerHeight();
        $el.animate({
            scrollTop: st < sb / 2 ? sb : 0
        }, 5000, anim);
    }

    function stop() {
        $el.stop();
    }
    anim();
    $el.hover(stop, anim);
};

